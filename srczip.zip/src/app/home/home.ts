// src/app/home/home.ts
import { Component, inject, ChangeDetectionStrategy } from '@angular/core';
import { AsyncPipe } from '@angular/common';
import { Observable } from 'rxjs';
import { Task, TaskItem } from '../core/services/task';

@Component({
  selector: 'app-home',
  standalone: true,
  imports: [AsyncPipe],
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './home.html',
  styleUrls: ['./home.css'],
})
export class HomeComponent {
  private readonly taskService = inject(Task);

  readonly tasks$: Observable<TaskItem[]> = this.taskService.tasks$;

  addTask(title: string, description: string): void {
    this.taskService.addTask(title, description);
  }
  removeTask(id: number) {
  this.taskService.removeTask(id);
}

}
